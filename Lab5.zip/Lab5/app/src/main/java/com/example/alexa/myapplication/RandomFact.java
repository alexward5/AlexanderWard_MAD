package com.example.alexa.myapplication;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.Random;

public class RandomFact extends AppCompatActivity {

    private TextView factTextView;
    private Button showFactButton;
    private Switch boldSwitch;
    private CheckBox boldText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_fact);

        factTextView = findViewById(R.id.TextView);
        showFactButton = findViewById(R.id.FactButton);
        boldSwitch = findViewById(R.id.switch1);

        View.OnClickListener buttonListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] facts = {
                        "Prarie dogs say hello by kissing.",
                        "Nine-banded armadillos always give birth to identical quadruplets.",
                        "Some cats are allergic to humans.",
                        "Tigers have striped skin as well. Each pattern is as unique as a fingerprint.",
                        "A grizzly bear's bite is strong enough to crush a bowling ball."
                };
                Random randomGenerator = new Random();
                int randomNumber = randomGenerator.nextInt(facts.length);
                String fact = facts[randomNumber]+"";
                factTextView.setText(fact);
            }
        };
        showFactButton.setOnClickListener(buttonListener);

        View.OnClickListener toggleListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        };

        boldSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true) {
                    factTextView.setTextColor(Color.RED);
                    Toast.makeText(getBaseContext(), "Text color changed to red", Toast.LENGTH_SHORT).show();
                }
                else {
                    factTextView.setTextColor(Color.BLACK);
                }
            }
        });
    }

    public void changeBackground(View view) {
        boolean checked = ((ToggleButton)view).isChecked();
        if (checked) {
            factTextView.setAllCaps(true);
        }
        else {
            factTextView.setAllCaps(false);
        }
    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton)view).isChecked();

        switch(view.getId()) {
            case R.id.radioButton:
                if(checked)
                    factTextView.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
                break;
        }
    }

    public void boldText(View view) {
        boolean checked = ((CheckBox)view).isChecked();

        if (checked) {
            factTextView.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        }
        else {
            factTextView.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
        }
    }

}
