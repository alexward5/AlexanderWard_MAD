package com.example.alexa.dogfinder;

public class Dog {

    private String dog;
    private String dogURL;

    private void setDogInfo(Integer dogType) {

        switch (dogType) {
            case 0: //big dog
                dog = "Great Dane";
                dogURL = "https://www.google.com/search?q=great+dane&source=lnms&tbm=isch&sa=X&ved=0ahUKEwiboOal5PHXAhUK4IMKHbViCDcQ_AUICigB&biw=1280&bih=615";
                break;
            case 1: //small dog
                dog = "Tea Cup Poodle";
                dogURL = "https://www.google.com/search?biw=1280&bih=615&tbm=isch&sa=1&ei=B_8lWvC1PMGKjwSw4Z-oDQ&q=teacup+poodle&oq=teacup+poodle&gs_l=psy-ab.3...63344.65696.0.65824.0.0.0.0.0.0.0.0..0.0....0...1c.1.64.psy-ab..0.0.0....0.QLyNCuUtEQY";
                break;
            case 2: //hot dog
                dog = "Chicago Dog";
                dogURL = "https://www.google.com/search?q=chicago+dog&source=lnms&tbm=isch&sa=X&ved=0ahUKEwihtb23o_LXAhXm54MKHQj5DrYQ_AUICigB&biw=1280&bih=566";
                break;
        }
    }

    public void setDogType(Integer dogType) {
        setDogInfo(dogType);
    }

    public void setDogURL(Integer dogType) {
        setDogInfo(dogType);
    }

    public String getDogType() {
        return dog;
    }

    public String getDogURL() {
        return dogURL;
    }

}
