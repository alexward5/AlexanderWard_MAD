package com.example.alexa.dogfinder;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class ResultsActivity extends AppCompatActivity {

    private String dog;
    private String dogURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        Intent intent = getIntent();
        dog = intent.getStringExtra("typeOfDog");
        dogURL = intent.getStringExtra("dogURL");
        Log.i("dog received", dog);
        Log.i("URL received", dogURL);

        TextView messageView = (TextView) findViewById(R.id.textView2);
        String message = "The perfect dog for you is a";
        messageView.setText(message + " " + dog);

        final ImageButton imageButton = (ImageButton) findViewById(R.id.imageButton2);

        View.OnClickListener onClick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadDogWebsite(view);
            }
        };
        imageButton.setOnClickListener(onClick);
    }

    public void loadDogWebsite(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(dogURL));
        startActivity(intent);
    }
}
