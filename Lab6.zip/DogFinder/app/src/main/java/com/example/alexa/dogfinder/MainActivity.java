package com.example.alexa.dogfinder;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    private Dog myDog = new Dog();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = (Button) findViewById(R.id.button);

        View.OnClickListener onClick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                findDog(view);
            }
        };
        button.setOnClickListener(onClick);
    }

    public void findDog(View view) {
        Spinner dogSpinner = (Spinner)findViewById(R.id.spinner);
        Integer dogInt = dogSpinner.getSelectedItemPosition();
        myDog.setDogType(dogInt);
        String suggestedDog = myDog.getDogType();
        String suggestedDogURL = myDog.getDogURL();
        Log.i("dog", suggestedDog);
        Log.i("url", suggestedDogURL);

        Intent intent = new Intent(this, ResultsActivity.class);

        intent.putExtra("typeOfDog", suggestedDog);
        intent.putExtra("dogURL", suggestedDogURL);

        startActivity(intent);
    }
}
