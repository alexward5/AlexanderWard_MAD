package com.example.alexa.project2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SellActivity extends AppCompatActivity {

    EditText editTextTitle;
    EditText editTextPrice;
    Button listTextbookButton;

    DatabaseReference databaseTextbooks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);

        databaseTextbooks = FirebaseDatabase.getInstance().getReference("textbooks");

        editTextTitle = findViewById(R.id.editTextTitle);
        editTextPrice = findViewById(R.id.editTextPrice);
        listTextbookButton = findViewById(R.id.buttonListTextbook);

        listTextbookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTextbook();
            }
        });
    }

    private void addTextbook() {
        String title = editTextTitle.getText().toString().trim();
        String price = editTextPrice.getText().toString().trim();

        if((!TextUtils.isEmpty(title)) && (!TextUtils.isEmpty(price))) {

            String id = databaseTextbooks.push().getKey();
            Textbook textbook = new Textbook(id, title, price);
            databaseTextbooks.child(id).setValue(textbook);
            Toast.makeText(this, "Textbook successfully listed.", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(this, "Please enter a title and price.", Toast.LENGTH_LONG).show();
        }
    }

}
