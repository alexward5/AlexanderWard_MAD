package com.example.alexa.project2;

public class Textbook {
    String textbookID;
    String textbookTitle;
    String textbookPrice;

    public Textbook() {

    }

    public Textbook(String textbookID, String textbookTitle, String textbookPrice) {
        this.textbookID = textbookID;
        this.textbookTitle = textbookTitle;
        this.textbookPrice = textbookPrice;
    }

    public String getTextbookID() {
        return textbookID;
    }

    public String getTextbookTitle() {
        return textbookTitle;
    }

    public String getTextbookPrice() {
        return textbookPrice;
    }
}
