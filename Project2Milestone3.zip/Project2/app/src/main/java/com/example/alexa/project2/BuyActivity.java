package com.example.alexa.project2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class BuyActivity extends AppCompatActivity {

    ListView listViewTextbooks;
    DatabaseReference databaseTextbooks;

    List<Textbook> textbookList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);

        databaseTextbooks = FirebaseDatabase.getInstance().getReference("textbooks");

        listViewTextbooks = (ListView) findViewById(R.id.listViewTextbooks);

        textbookList = new ArrayList<>();
    }

    @Override
    protected void onStart() {
        super.onStart();

        databaseTextbooks.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                textbookList.clear();

                for(DataSnapshot textbookSnapshot: dataSnapshot.getChildren()) {
                    Textbook textbook = textbookSnapshot.getValue(Textbook.class);

                    textbookList.add(textbook);
                }

                TextbookList adapter = new TextbookList(BuyActivity.this, textbookList);
                listViewTextbooks.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
