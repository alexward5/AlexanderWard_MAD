package com.example.alexa.midterm2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    Button buildButton;
    ToggleButton toggleButton;
    Switch switchGluten;
    TextView description;

    String meatOrVeg = "veggie";
    String glutenFree = "non gluten-free";

    Button buttonFindBurrito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buildButton = findViewById(R.id.buttonBuild);
        description = findViewById(R.id.textDescription);
        switchGluten = findViewById(R.id.switchGluten);

        buttonFindBurrito = findViewById(R.id.buttonFindBurrito);

        //build button listener
        View.OnClickListener buildListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buildBurrito(v);
            }
        };

        buildButton.setOnClickListener(buildListener);

        //switch for gluten free

        switchGluten.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true) {
                    glutenFree = "gluten-free";
                }
                else {
                    glutenFree = "non-gluten-free";
                }
            }
        });

        //find burrito button
        View.OnClickListener findListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findBurrito(v);
            }
        };

        buttonFindBurrito.setOnClickListener(findListener);
    }

    public void buildBurrito(View view) {
        String location = "on The Hill";
        Spinner locationSpinner = findViewById(R.id.spinnerLocation);
        Integer spinnerInt = locationSpinner.getSelectedItemPosition();

        if (spinnerInt == 0) {
            location = "on The Hill";
        }
        else if (spinnerInt == 1) {
            location = "on 29th Street";
        }
        else if (spinnerInt == 2) {
            location = "on Pearl Street";
        }

        description.setText("A " + meatOrVeg + " " + glutenFree + " burrito you would like to eat " + location);
    }

    public void veggieOrMeat(View view) {
        boolean checked = ((ToggleButton)view).isChecked();
        if (checked) {
            meatOrVeg = "meat";
        }
        else {
            meatOrVeg = "veggie";
        }
    }

    //find burrito func
    public void findBurrito(View view) {
        String locationString = "Illegal Petes";
        String websiteString = "http://illegalpetes.com/";
        Spinner locationSpinner = findViewById(R.id.spinnerLocation);
        Integer spinnerInt = locationSpinner.getSelectedItemPosition();

        if (spinnerInt == 0) {
            locationString = "Illegal Petes";
            websiteString = "http://illegalpetes.com/";
        }
        else if (spinnerInt == 1) {
            locationString = "Chipotle";
            websiteString = "https://www.chipotle.com/";
        }
        else if (spinnerInt == 2) {
            locationString = "Bartaco";
            websiteString = "https://bartaco.com/";
        }

        Intent intent = new Intent(this, FindBurritoActivity.class);

        intent.putExtra("location", locationString);
        intent.putExtra("website",websiteString);

        startActivity(intent);
    }
}
