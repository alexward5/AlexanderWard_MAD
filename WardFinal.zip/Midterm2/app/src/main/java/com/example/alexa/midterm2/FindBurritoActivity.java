package com.example.alexa.midterm2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FindBurritoActivity extends AppCompatActivity {

    String location;
    String website = "http://illegalpetes.com/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_burrito);

        TextView locationDisplay = findViewById(R.id.locationText);
        String message = "You should check out ";

        Intent intent = getIntent();
        location = intent.getStringExtra("location");
        website = intent.getStringExtra("website");

        locationDisplay.setText(message + location);

        //visist website
        Button websiteButton = findViewById(R.id.buttonWebsite);

        View.OnClickListener onClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewWebsite(v);
            }
        };

        websiteButton.setOnClickListener(onClick);
    }

    public void viewWebsite(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(website));
        startActivity(intent);
    }
}
