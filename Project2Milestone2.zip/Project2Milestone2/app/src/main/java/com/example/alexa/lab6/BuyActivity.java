package com.example.alexa.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class BuyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);

        resultsSetup();
    }

    private void resultsSetup() {
        Button resultsButton = findViewById(R.id.Results);
        resultsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //launch results activity
                Intent intent = new Intent(BuyActivity.this, ResultsActivity.class);
                startActivity(intent);
            }
        });
    }
}
