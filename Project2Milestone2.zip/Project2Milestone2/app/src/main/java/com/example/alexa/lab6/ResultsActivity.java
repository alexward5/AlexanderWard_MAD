package com.example.alexa.lab6;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ResultsActivity extends AppCompatActivity {

    String[] resultsArray = {};
    ListView myListView;
    //ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        myListView = findViewById(R.id.resultsListView);

        HashMap<String, String> titleAuthor = new HashMap<>();
        titleAuthor.put("Calculus", "Author1");
        titleAuthor.put("iOS Development", "Author2");
        titleAuthor.put("Android Development", "Author3");

        List<HashMap<String, String>> listItems = new ArrayList<>();
        SimpleAdapter adapter = new SimpleAdapter(this, listItems, R.layout.list_item,
            new String[]{"First Line", "Second Line"},
            new int[]{R.id.text1, R.id.text2});
        ;

        Iterator it = titleAuthor.entrySet().iterator();
        while (it.hasNext()) {
            HashMap<String, String> resultMap = new HashMap<>();
            Map.Entry pair = (Map.Entry)it.next();
            resultMap.put("First Line", pair.getKey().toString());
            resultMap.put("Second Line", pair.getValue().toString());
            listItems.add(resultMap);
        }
        myListView.setAdapter(adapter);
    }

}
