package com.example.alexa.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buyTextbookSetup();
        sellTextbookSetup();
    }

    private void buyTextbookSetup() {
        Button buyTextbookButton = findViewById(R.id.buyButton);
        buyTextbookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //launch buy activity
                Intent intent = new Intent(MainActivity.this, BuyActivity.class);
                startActivity(intent);
            }
        });
    }

    private void sellTextbookSetup() {
        Button sellTextbookButton = findViewById(R.id.sellButton);
        sellTextbookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //launch sell activity
                Intent intent = new Intent(MainActivity.this, SellActivity.class);
                startActivity(intent);
            }
        });
    }
}
